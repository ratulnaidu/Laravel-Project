

<?php $__env->startSection('content'); ?>


<center>
<div style="background: -webkit-linear-gradient(top, #b8c6df 0%,#6d88b7 100%);">
	<br>
<h1>Metropolitan University,Sylhet Bangladesh</h1>
	<h2> Students Register </h2>

	<br>
	<button><a href="<?php echo e(route('students.create')); ?>"> Register </a></button>

	<br>
	<hr>
<br><br><br><br>
	<table border="2" width="1000" style="background: linear-gradient(to bottom, #deefff 0%,#98bede 100%);">
		<tr>
			<th> Student ID </th>
			<th> Full Name </th>
			<th> Batch </th>
			<th> Department</th>
			<th> Session</th>
			<th> Section</th>
			<th> Action </th>
		</tr>

		<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr> 
			<td> <center><?php echo e($student->student_id); ?> </center>  </td>
			<td><center> <?php echo e($student->name); ?></center>  </td>
			<td><center> <?php echo e($student->batch); ?></center>  </td>
			<td><center> <?php echo e($student->department); ?></center>  </td>
			<td><center> <?php echo e($student->SESSION); ?></center>  </td>
			<td><center> <?php echo e($student->section); ?></center>  </td>
			<td>
				<form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="POST">
					
				<center>
					<br>
					<button><a href="<?php echo e(route('students.edit', $student->id)); ?>" >Edit</a></button>					
					<?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?> 

					<button type="submit" > Delete </button>
					</center>
				</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

	</table>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	</center>

</div>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/index.blade.php ENDPATH**/ ?>