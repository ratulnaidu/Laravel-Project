<html>
<head> 
	<title> Student Records </title>
</head>
<body>
	<div class="container"> 
		<?php echo $__env->yieldContent('content'); ?>
	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/layout.blade.php ENDPATH**/ ?>