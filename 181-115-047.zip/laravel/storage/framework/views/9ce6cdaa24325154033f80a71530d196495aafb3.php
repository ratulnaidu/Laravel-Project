<?php


echo 'Ratul 8'; ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/welcome.blade.php ENDPATH**/ ?>