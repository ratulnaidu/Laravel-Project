

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div  >
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
 
<div style="background: -webkit-linear-gradient(top, #b8c6df 0%,#6d88b7 100%);">
	<center>
		<br><br><br><br>
		<h1>Metropolitan University,Sylhet Bangladesh</h1>
	<form action="<?php echo e(route('students.update',$student->id)); ?>" method="POST">
 	 	<?php echo csrf_field(); ?>
 	 	<?php echo method_field('PUT'); ?>
 	 	<br><br>
        <br><br>
        
		 Student ID :<input type="text" name="student_id" placeholder="Student ID (XXX-XXX-XXX)" value="<?php echo e($student->student_id); ?>"> 
		<br><br>

		Student Name :<input type="text" name="name" placeholder="Full Name"
		 value="<?php echo e($student->name); ?>">
		<br>
        <br>

		Student Batch :<input type="text" name="batch" placeholder="Batch" value="<?php echo e($student->batch); ?>">
		<br><br>
		Student Department :<input type="text" name="department" placeholder="Department" value="<?php echo e($student->department); ?>">
		<br><br>
		Student Session :<input type="text" name="SESSION" placeholder="Session" value="<?php echo e($student->SESSION); ?>">
		<br><br>
		Student Section :<input type="text" name="section" placeholder="Section" value="<?php echo e($student->section); ?>">
	
		<br> <br>
		<button type="submit" >Update</button>

		


	</form>
</center>
<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
</div>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/edit.blade.php ENDPATH**/ ?>