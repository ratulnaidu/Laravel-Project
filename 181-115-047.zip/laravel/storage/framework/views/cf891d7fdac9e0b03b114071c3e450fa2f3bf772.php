

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div>
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

    </div>
<?php endif; ?>


<div style="background: -webkit-linear-gradient(top, #b8c6df 0%,#6d88b7 100%);">
<div>

	<center>
		<br><br><br><br>
		<h1>Metropolitan University,Sylhet Bangladesh</h1>
	<form action="<?php echo e(route('students.store')); ?>" method="POST">
 	 	<?php echo csrf_field(); ?>
 	 	<br><br><br>
		 <input type="text" name="student_id" placeholder="Student ID (XXX-XXX-XXX)"> 
		<br><br>
		 <input type="text" name="name" placeholder="Full Name">
		<br><br>

		  <input type="text" name="batch" placeholder="Batch">
		<br><br>
		  <input type="text" name="department" placeholder="Department">
		  <br><br>
		  <input type="text" name="SESSION" placeholder="Session">
		  <br><br>
		  <input type="text" name="section" placeholder="Section">

		<br><br>
		<button type="submit" >Register</button>

	</form>
	
</center>
</div>
<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
</div>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/create.blade.php ENDPATH**/ ?>