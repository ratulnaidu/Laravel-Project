<html>
<head> 
	<title> Student Records </title>
</head>
<body>
	<div class="container"> 
		@yield('content')
	</div>

</body>
</html>