@extends('students.layout')

@section('content')


<center>
<div style="background: -webkit-linear-gradient(top, #b8c6df 0%,#6d88b7 100%);">
	<br>
<h1>Metropolitan University,Sylhet Bangladesh</h1>
	<h2> Students Register </h2>

	<br>
	<button><a href="{{ route('students.create') }}"> Register </a></button>

	<br>
	<hr>
<br><br><br><br>
	<table border="2" width="1000" style="background: linear-gradient(to bottom, #deefff 0%,#98bede 100%);">
		<tr>
			<th> Student ID </th>
			<th> Full Name </th>
			<th> Batch </th>
			<th> Department</th>
			<th> Session</th>
			<th> Section</th>
			<th> Gender</th>
			<th> Action </th>
		</tr>

		@foreach ($students as $student)
		<tr> 
			<td> <center>{{$student->student_id}} </center>  </td>
			<td><center> {{$student->name}}</center>  </td>
			<td><center> {{$student->batch}}</center>  </td>
			<td><center> {{$student->department}}</center>  </td>
			<td><center> {{$student->SESSION}}</center>  </td>
			<td><center> {{$student->section}}</center>  </td>
			<td><center> {{$student->gender}}</center>  </td>
			<td>
				<form action="{{ route('students.destroy', $student->id)}}" method="POST">
					
				<center>
					<br>
					<button><a href="{{ route('students.edit', $student->id)}}" >Edit</a></button>					
					@csrf
                    @method('DELETE') 

					<button type="submit" > Delete </button>
					</center>
				</form>
			</td>
		</tr>
		@endforeach 

	</table>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	</center>

</div>