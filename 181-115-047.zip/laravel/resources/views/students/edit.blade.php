@extends('students.layout')

@section('content')
@if ($errors->any())
    <div  >
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
 
<div style="background: -webkit-linear-gradient(top, #b8c6df 0%,#6d88b7 100%);">
	<center>
		<br><br><br><br>
		<h1>Metropolitan University,Sylhet Bangladesh</h1>
	<form action="{{route('students.update',$student->id) }}" method="POST">
 	 	@csrf
 	 	@method('PUT')
 	 	<br><br>
        <br><br>
        
		 Student ID :<input type="text" name="student_id" placeholder="Student ID (XXX-XXX-XXX)" value="{{$student->student_id}}"> 
		<br><br>

		Student Name :<input type="text" name="name" placeholder="Full Name"
		 value="{{$student->name}}">
		<br>
        <br>

		Student Batch :<input type="text" name="batch" placeholder="Batch" value="{{$student->batch}}">
		<br><br>
		Student Department :<input type="text" name="department" placeholder="Department" value="{{$student->department}}">
		<br><br>
		Student Session :<input type="text" name="SESSION" placeholder="Session" value="{{$student->SESSION}}">
		<br><br>
		Student Section :<input type="text" name="section" placeholder="Section" value="{{$student->section}}">
	
		<br> <br>
		
		 <label for="gender"><b>Gender:</b></label>
    <select   name="gender">
                          <option value="Male">Male</option>
                           <option value="Female">Female</option>
                           <option value="Others">Others</option>
                    </select>   
         <br><br>          
		<button type="submit" >Update</button>

		


	</form>
</center>
<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
</div>