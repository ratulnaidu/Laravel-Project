@extends('students.layout')

@section('content')
@if ($errors->any())
    <div>
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>

    </div>
@endif


<div style="background: -webkit-linear-gradient(top, #b8c6df 0%,#6d88b7 100%);">
<div>

	<center>
		<br><br><br><br>
		<h1>Metropolitan University,Sylhet Bangladesh</h1>
	<form action="{{route('students.store')}}" method="POST">
 	 	@csrf
 	 	<br><br><br>
		 <input type="text" name="student_id" placeholder="Student ID (XXX-XXX-XXX)"> 
		<br><br>
		 <input type="text" name="name" placeholder="Full Name">
		<br><br>

		  <input type="text" name="batch" placeholder="Batch">
		<br><br>
		  <input type="text" name="department" placeholder="Department">
		  <br><br>
		  <input type="text" name="SESSION" placeholder="Session">
		  <br><br>
		  <input type="text" name="section" placeholder="Section">

		<br><br>
		<button type="submit" >Register</button>

	</form>
	
</center>
</div>
<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
</div>